﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float m_speed;
    private Rigidbody2D rigidBody;
    private Vector2 move;
	private Animator anim = null;
    private Vector2 player_pos;
    Button button;
    GameObject chest1;
    GameObject chest2;
    GameObject chest3;
    Image mark1;
    Image mark2;
    Image mark3;
    GameObject collision_chest;
    bool judge = false;
    static int count = 0;

    // Start is called before the first frame update
    void Start()
    {
        // オブジェクトに設定しているRigidbody2Dの参照を取得する
        this.rigidBody = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        button = GameObject.Find("button").GetComponent<Button>();
        chest1 = GameObject.Find("chest1");
        chest2 = GameObject.Find("chest2");
        chest3 = GameObject.Find("chest3");
        mark1 = GameObject.Find("chest1_mark").GetComponent<Image>();
        mark2 = GameObject.Find("chest2_mark").GetComponent<Image>();
        mark3 = GameObject.Find("chest3_mark").GetComponent<Image>();
    }

    // Update is called once per frame
    void Update()
    {
        // x,ｙの入力値を得る
        // それぞれ+や-の値と入力の関連付けはInput Managerで設定されている
        move.x = Input.GetAxis("Horizontal");
        move.y = Input.GetAxis("Vertical");
        player_pos = transform.position;

        //プレイヤーの移動範囲制限
        player_pos.x = Mathf.Clamp(player_pos.x, -11.5f, 7.7f);
        player_pos.y = Mathf.Clamp(player_pos.y, 0.0f, 19.0f);
        transform.position = new Vector2(player_pos.x, player_pos.y);

        //アニメーションの設定
        //水平方向の移動
        if (move.x > 0)
        {
            //右向きにする
            transform.localScale = new Vector3(-1, 1, 1);
            anim.SetBool("x", true);
        }
        else if (move.x < 0)
        {
            //左向きにする
            transform.localScale = new Vector3(1, 1, 1);
            anim.SetBool("x", true);
        }
        else
        {
            anim.SetBool("x", false);
        }

        //上向きの移動
        if (move.y > 0)
        {
            anim.SetBool("up", true);
        }
        else 
        {
            anim.SetBool("up", false);
        }

        //下向きに移動
        if (move.y < 0)
        {
            anim.SetBool("down", true);
        }
        else
        {
            anim.SetBool("down", false);
        }

        // ボタンをクリックした時の処理
        if (button.gameObject.activeSelf == false && judge == true) {
            Destroy(collision_chest.gameObject);
            count += 1;
            if (count == 1) {
                mark1.color = Color.white;
            } else if (count == 2) {
                mark2.color = Color.white;
            } else {
                mark3.color = Color.white;
                Debug.Log("クリア！");
            }
        }
    }

    private void FixedUpdate()
    {
        // 速度を代入する
        rigidBody.velocity = move.normalized * m_speed;
    }


    // 衝突した時の処理
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Treasure") {
            button.gameObject.SetActive (true);
            judge = true;
            collision_chest = other.gameObject;
        }
    }

    void OnCollisionExit2D(Collision2D other)
    {
        if (other.gameObject.tag == "Treasure") {
            button.gameObject.SetActive (false);
            judge = false;
        }
    }

}
