﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCont : MonoBehaviour
{
    public Transform target;
    private Vector3 offset;

    void Start ()
    {
        offset = transform.position - target.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        Vector3 camera_pos = target.position + offset;
        camera_pos = Vector3.Lerp(transform.position,camera_pos,1);
        camera_pos.x = Mathf.Clamp(camera_pos.x, -7.4f, 3.6f);
        camera_pos.y = Mathf.Clamp(camera_pos.y, 2.5f, 16.5f);
        transform.position = camera_pos;
    }
}
