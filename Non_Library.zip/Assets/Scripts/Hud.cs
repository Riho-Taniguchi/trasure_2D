﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Hud : MonoBehaviour
{

    public Text timeText;
    private float now;

    public Image chest1;
    public Image chest2;
    public Image chest3;
    

    // Start is called before the first frame update
    void Start()
    {
        now = 0;
    }

    // Update is called once per frame
    void Update()
    {
        now += Time.deltaTime;
        timeText.text = "Time : " + now.ToString("f1");

    }

}
